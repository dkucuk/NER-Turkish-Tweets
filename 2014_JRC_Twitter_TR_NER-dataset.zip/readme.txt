﻿(In English)

February 10, 2014

=Readme File for the Named Entity Annotations of a Turkish Tweet Data Set=

-The file (twitter_tr_dataset_ner_annotations.txt) includes the annotations for named entities within a tweet data set in Turkish.

-The data set contains a total of 1,322 named entity annotations (one at each line beginning from the second line) from a total of 868 Turkish tweets published on July 26, 2013 within the time interval between 12:00 and 13:00 in GMT.

-At each annotation line, following information is presented as separated with tab characters: tweet id of the corresponding tweet, position of the starting character of the named entity annotated, position of the last (ending) character of the named entity, and finally named entity type (being one of PERSON, LOCATION, ORGANIZATION, DATE, TIME, MONEY, PERCENT, or MISC). Tweet ids provided can be used to retrieve the corresponding tweet texts.

-The first line ("#tweet_id start_pos end_pos named_entity_type") of the file is added to specify the above information regarding the annotations, so it is not part of the actual annotations.


Please use the following publication as a reference when reporting your work on this data set:

Küçük, D., Jacquet, G. and Steinberger, R. 2014. Named Entity Recognition on Turkish Tweets. In Proceedings of the Language Resources and Evaluation Conference (LREC). Reykjavik, Iceland.


For questions or comments regarding the data set, you can contact the following people by e-mail:

Dilek Küçük
dilekkucuk@gmail.com

Guillaume Jacquet 
guillaume.jacquet@jrc.ec.europa.eu

Ralf Steinberger
ralf.steinberger@jrc.ec.europa.eu




(In Turkish)

10 Şubat 2014

=Türkçe Bir Tweet Veri Kümesine ait Varlık İsmi İşaretlemeleri için Benioku Dosyası=

-twitter_tr_dataset_ner_annotations.txt dosyası, Türkçe bir tweet veri kümesinde yer alan varlık isimlerine ait işaretlemeleri (bilgileri) içermektedir.

-Veri kümesi (ikinci satırdan itibaren her satırda bir tane olacak şekilde) 26 Temmuz 2013 tarihinde (GMT olarak) 12:00 ve 13:00 saatleri arasında yayınlanmış toplam 868 Türkçe tweet'te yer alan toplam 1,322 varlık ismi bilgisini içermektedir.

-Her işaretleme satırında, şu bilgiler tab karakterleriyle ayrılmış olarak yer almaktadır: ilgili tweet'in tweet id'si, işaretlenmiş varlık isminin başlangıç karakterinin sırası, varlık isminin son karakterinin sırası, ve son olarak varlık isminin türü (PERSON, LOCATION, ORGANIZATION, DATE, TIME, MONEY, PERCENT veya MISC türlerinden biri olacak şekilde). Karşılık gelen tweet metinlerini elde etmek için verilen tweet id'leri kullanılabilir.

-Dosyanın ilk satırı ("#tweet_id start_pos end_pos named_entity_type") işaretlemelerle ilgili yukarıdaki bilgiyi belirtmek için eklenmiştir, dolayısıyla asıl işaretlemelere dahil değildir.


Bu veri kümesi üzerinde yaptığınız çalışmalarınızı raporlarken lütfen aşağıdaki yayını referans olarak kullanınız:

Küçük, D., Jacquet, G. and Steinberger, R. 2014. Named Entity Recognition on Turkish Tweets. In Proceedings of the Language Resources and Evaluation Conference (LREC). Reykjavik, Iceland.


Veri kümesi ile ilgili sorularınız ve yorumlarınız için, e-posta yoluyla aşağıdaki kişilere başvurabilirsiniz:

Dilek Küçük
dilekkucuk@gmail.com

Guillaume Jacquet 
guillaume.jacquet@jrc.ec.europa.eu

Ralf Steinberger
ralf.steinberger@jrc.ec.europa.eu

